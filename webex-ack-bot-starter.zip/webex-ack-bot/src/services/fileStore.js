import fs from 'fs';
import path from 'path';

export class FileStore {
  constructor({ dataDir = 'data' } = {}) {
    this.dataDir = dataDir;
    this.filePath = path.join(this.dataDir, 'store.json');
    if (!fs.existsSync(this.dataDir)) fs.mkdirSync(this.dataDir, { recursive: true });
    if (!fs.existsSync(this.filePath)) fs.writeFileSync(this.filePath, JSON.stringify({ rooms: {} }, null, 2));
  }

  _load() {
    return JSON.parse(fs.readFileSync(this.filePath, 'utf-8'));
  }

  _save(data) {
    fs.writeFileSync(this.filePath, JSON.stringify(data, null, 2));
  }

  /**
   * Record acknowledgement
   */
  async ack(roomId, taskId, personEmail) {
    const data = this._load();
    data.rooms[roomId] = data.rooms[roomId] || { tasks: {} };
    const task = (data.rooms[roomId].tasks[taskId] = data.rooms[roomId].tasks[taskId] || { acknowledgedBy: [] });
    if (!task.acknowledgedBy.includes(personEmail)) task.acknowledgedBy.push(personEmail);
    this._save(data);
  }

  async getAcks(roomId, taskId) {
    const data = this._load();
    const task = data.rooms?.[roomId]?.tasks?.[taskId];
    return task?.acknowledgedBy || [];
  }
}
