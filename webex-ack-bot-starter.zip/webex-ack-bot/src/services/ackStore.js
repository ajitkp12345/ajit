import { FileStore } from './fileStore.js';
// Placeholder for Mongo store import if needed later
// import { MongoStore } from './mongoStore.js';

const singleton = { store: null };

export const getStore = (opts = {}) => {
  if (singleton.store) return singleton.store;

  // If you later enable Mongo, detect MONGODB_URI here and construct MongoStore
  singleton.store = new FileStore({ dataDir: opts.dataDir || 'data' });
  return singleton.store;
};
