// (Optional) MongoDB store – scaffold for future use
// You can implement this using mongoose with a TaskAck schema if MONGODB_URI is set.
export class MongoStore { /* TODO: implement if needed */ }
